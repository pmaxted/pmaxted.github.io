Supplementary material to accompany "Fundamental effective temperature
measurements for eclipsing binary stars – VI. Improved methodology and
application to the circumbinary planet host star BEBOP-3"

Maxted et al. 2025

The supplementary material consists of three files:
 - BEBOP-3_SOPHIE.fits
 - BEBOP-3_SOPHIE.txt
 - BEBOP-3_final.fits

The first two files contain the average of 61 of the spectra of BEBOP-3
obtained with the SOPHIE spectrograph observed at an airmass <1.4. Wavelengths
are in nm and flux is in arbitrary units. BEBOP-3_SOPHIE.txt is a
tab-separated file with wavelengths in-air. BEBOP-3_SOPHIE.fits is a FITS
binary table with both vacuum and in-air wavelengths.

BEBOP-3_final.fits is the output file from our analysis. 

-Pierre Maxted (p.maxted@keele.ac.uk)
 2025-09-30 
